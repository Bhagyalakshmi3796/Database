﻿CREATE TABLE [dbo].[Screens] (
    [ScreenId]   INT            IDENTITY (1, 1) NOT NULL,
    [ScreenName] NVARCHAR (100) NULL,
    CONSTRAINT [PK_Screens] PRIMARY KEY CLUSTERED ([ScreenId] ASC)
);

