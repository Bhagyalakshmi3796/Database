﻿CREATE TABLE [dbo].[DellManager] (
    [DellManagerId]   INT            IDENTITY (1, 1) NOT NULL,
    [DellManagerName] NVARCHAR (100) NULL,
    [IsDeleted]       BIT            CONSTRAINT [DF_DellManager_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_DellManagerName] PRIMARY KEY CLUSTERED ([DellManagerId] ASC)
);

