﻿CREATE TABLE [dbo].[Location] (
    [LocationId] INT           IDENTITY (1, 1) NOT NULL,
    [Location]   NVARCHAR (50) NULL,
    [RegionId]   INT           NOT NULL,
    [IsDeleted]  BIT           CONSTRAINT [DF_Location_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_Location] PRIMARY KEY CLUSTERED ([LocationId] ASC),
    CONSTRAINT [FK_Location_Region] FOREIGN KEY ([RegionId]) REFERENCES [dbo].[Region] ([RegionId])
);

