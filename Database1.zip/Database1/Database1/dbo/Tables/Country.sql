﻿CREATE TABLE [dbo].[Country] (
    [CountryId]   INT            NOT NULL,
    [CountryName] NVARCHAR (100) NULL,
    [RegionId]    INT            NULL,
    [IsDeleted]   BIT            CONSTRAINT [DF_Country_IsDeleted] DEFAULT ((0)) NULL
);

