﻿CREATE TABLE [dbo].[Technology] (
    [TechnologyId]   INT            IDENTITY (1, 1) NOT NULL,
    [TechnologyName] NVARCHAR (100) NULL,
    [DomainId]       INT            NOT NULL,
    [IsDeleted]      BIT            CONSTRAINT [DF_Technology_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_Technology] PRIMARY KEY CLUSTERED ([TechnologyId] ASC),
    CONSTRAINT [FK_Technology_Technology] FOREIGN KEY ([DomainId]) REFERENCES [dbo].[Domain] ([DomainId])
);

