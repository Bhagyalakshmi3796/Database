﻿CREATE TABLE [dbo].[Candidate] (
    [CandidateId]   INT            NOT NULL,
    [CandidateName] NVARCHAR (50)  NULL,
    [MobileNo]      NVARCHAR (50)  NULL,
    [DOB]           DATE           NULL,
    [EmailId]       NVARCHAR (50)  NULL,
    [Location]      NVARCHAR (50)  NULL,
    [Skills]        NVARCHAR (MAX) NULL,
    [JoiningDate]   DATETIME       NULL,
    [IsInternal]    BIT            NOT NULL,
    [IsDeleted]     BIT            CONSTRAINT [DF_Candidate_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_Candidate] PRIMARY KEY CLUSTERED ([CandidateId] ASC)
);

