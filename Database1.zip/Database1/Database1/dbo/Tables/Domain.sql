﻿CREATE TABLE [dbo].[Domain] (
    [DomainId]  INT            IDENTITY (1, 1) NOT NULL,
    [Domain]    NVARCHAR (100) NULL,
    [IsDeleted] BIT            CONSTRAINT [DF_Domain_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_Domain] PRIMARY KEY CLUSTERED ([DomainId] ASC)
);

