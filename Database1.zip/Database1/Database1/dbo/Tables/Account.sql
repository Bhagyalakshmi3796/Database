﻿CREATE TABLE [dbo].[Account] (
    [AccountId]   INT            NOT NULL,
    [AccountName] NVARCHAR (100) NULL,
    [IsDeleted]   BIT            CONSTRAINT [DF_Account_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_Account] PRIMARY KEY CLUSTERED ([AccountId] ASC)
);

