﻿CREATE TABLE [dbo].[SOWCandidate] (
    [SOW_CandidateId] INT IDENTITY (1, 1) NOT NULL,
    [SowId]           INT NOT NULL,
    [CandidateId]     INT NOT NULL,
    [StatusId]        INT NULL,
    [IsDeleted]       BIT CONSTRAINT [DF_SOWCandidate_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_SOWCandidate] PRIMARY KEY CLUSTERED ([SOW_CandidateId] ASC),
    CONSTRAINT [FK_SOWCandidate_Candidate] FOREIGN KEY ([CandidateId]) REFERENCES [dbo].[Candidate] ([CandidateId]),
    CONSTRAINT [FK_SOWCandidate_SOW] FOREIGN KEY ([SowId]) REFERENCES [dbo].[SOW] ([SowId]),
    CONSTRAINT [FK_SOWCandidate_SOWCandidate] FOREIGN KEY ([StatusId]) REFERENCES [dbo].[Status] ([StatusId])
);

