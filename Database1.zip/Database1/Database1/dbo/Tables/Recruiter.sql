﻿CREATE TABLE [dbo].[Recruiter] (
    [RecruiterId]   INT            IDENTITY (1, 1) NOT NULL,
    [RecruiterName] NVARCHAR (100) NULL,
    [IsDeleted]     BIT            CONSTRAINT [DF_Recruiter_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_RecruiterName] PRIMARY KEY CLUSTERED ([RecruiterId] ASC)
);

