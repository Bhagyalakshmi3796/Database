﻿CREATE TABLE [dbo].[Region] (
    [RegionId]  INT            IDENTITY (1, 1) NOT NULL,
    [Region]    NVARCHAR (100) NULL,
    [IsDeleted] BIT            CONSTRAINT [DF_Region_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_Region] PRIMARY KEY CLUSTERED ([RegionId] ASC)
);

