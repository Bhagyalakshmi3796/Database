﻿CREATE TABLE [dbo].[Login] (
    [LoginId]       INT            IDENTITY (1, 1) NOT NULL,
    [LoginName]     NVARCHAR (100) NULL,
    [LoginPassword] NVARCHAR (100) NULL,
    [EmailId]       NVARCHAR (200) NULL,
    [RoleId]        INT            NOT NULL,
    CONSTRAINT [PK_Login] PRIMARY KEY CLUSTERED ([LoginId] ASC)
);

