﻿CREATE TABLE [dbo].[Status] (
    [StatusId]   INT            IDENTITY (1, 1) NOT NULL,
    [StatusName] NVARCHAR (100) NULL,
    [IsDeleted]  BIT            CONSTRAINT [DF_Status_IsDeleted] DEFAULT ((0)) NULL,
    CONSTRAINT [PK_Status] PRIMARY KEY CLUSTERED ([StatusId] ASC)
);

