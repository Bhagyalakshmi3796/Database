﻿CREATE TABLE [dbo].[RoleScreens] (
    [RoleScreenId] INT IDENTITY (1, 1) NOT NULL,
    [RoleId]       INT NOT NULL,
    [ScreenId]     INT NOT NULL,
    CONSTRAINT [PK_RoleScreens] PRIMARY KEY CLUSTERED ([RoleScreenId] ASC)
);

