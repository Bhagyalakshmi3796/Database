﻿
 
      
CREATE procedure [dbo].[SowCandidate_proc]    
(    
@SOW_CandidateId int,    
@SowId int,    
@CandidateId int,    
@StatusId int,    
@Type nvarchar(100)    
)    
AS BEGIN    
IF(@Type='post')    
BEGIN INSERT INTO SOWCandidate(SowId,CandidateId,StatusId)    
VALUES(@SowId,@CandidateId,@StatusId)    
END    
    
ELSE IF(@Type='get')        
BEGIN        
  SELECT * FROM SOWCandidate where IsDeleted=0 order by SOW_CandidateId desc        
END       
    
    
ELSE IF(@Type='getid')        
BEGIN        
  SELECT * FROM SOWCandidate where SOW_CandidateId=@SOW_CandidateId       
END     
    
ELSE IF(@Type='update')        
BEGIN        
update SOWCandidate SET     
SowId=@SowId,    
CandidateId=@CandidateId,StatusId=@StatusId   where SOW_CandidateId=@SOW_CandidateId
END    
    
ELSE IF(@Type='Delete')        
BEGIN        
 --DELETE FROM SOWCandidate WHERE SOW_CandidateId=@SOW_CandidateId
  update SOWCandidate SET IsDeleted=1 where SOW_CandidateId=@SOW_CandidateId
END     
    
    
END
