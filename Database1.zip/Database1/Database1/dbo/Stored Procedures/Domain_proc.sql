﻿
        
CREATE procedure [dbo].[Domain_proc]      
(      
@DomainId int,      
@Domain nvarchar(100),      
@Type nvarchar(100)      
)      
AS BEGIN      
IF(@Type='post')      
BEGIN INSERT INTO Domain(Domain)      
VALUES(@Domain)      
END      
   

ELSE IF(@Type='get')          
BEGIN          
  SELECT * FROM Domain where IsDeleted=0 order by DomainId desc          
END         
      
 
ELSE IF(@Type='getid')          
BEGIN          
  SELECT * FROM Domain where DomainId=@DomainId        
END       
   
ELSE IF(@Type='update')          
BEGIN          
update Domain SET       
      
Domain=@Domain  where DomainId=@DomainId    
END      

        
ELSE IF(@Type='Delete')          
BEGIN          
 --DELETE FROM Domain  where DomainId=@DomainId    
 update Domain SET IsDeleted=1 where DomainId=@DomainId 
END       
      
      
END
