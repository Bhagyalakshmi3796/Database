﻿

  
    
CREATE procedure [dbo].[USTPOC_proc]    
(    
@USTPOCId int,    
@USTPOCName nvarchar(100),    
@Type nvarchar(100)    
)    
AS BEGIN    
IF(@Type='post')    
BEGIN INSERT INTO USTPOC(USTPOCName)    
VALUES(@USTPOCName)    
END    
    
ELSE IF(@Type='get')        
BEGIN        
  SELECT * FROM USTPOC where IsDeleted=0 order by USTPOCId desc        
END       
    
    
ELSE IF(@Type='getid')        
BEGIN        
  SELECT * FROM USTPOC where USTPOCId= @USTPOCId     
END     
    
ELSE IF(@Type='update')        
BEGIN        
update USTPOC SET     
USTPOCName=@USTPOCName  WHERE USTPOCId= @USTPOCId   
    
END    
    
ELSE IF(@Type='Delete')        
BEGIN        
 --DELETE FROM USTPOC WHERE USTPOCId= @USTPOCId   
  update USTPOC SET IsDeleted=1 where USTPOCId= @USTPOCId  
END     
    
    
END
