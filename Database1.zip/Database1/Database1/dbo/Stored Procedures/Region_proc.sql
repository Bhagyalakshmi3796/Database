﻿
      
CREATE procedure [dbo].[Region_proc]    
(    
@RegionId int,    
@Region nvarchar(100),    
@Type nvarchar(100)    
)    
AS BEGIN    
IF(@Type='post')    
BEGIN INSERT INTO Region(Region)    
VALUES(@Region)    
END    
    
ELSE IF(@Type='get')        
BEGIN        
  SELECT * FROM Region where IsDeleted=0 order by RegionId desc        
END       
    
    
ELSE IF(@Type='getid')        
BEGIN        
  SELECT * FROM Region where RegionId=@RegionId       
END     
    
ELSE IF(@Type='update')        
BEGIN        
update Region SET     
    
Region=@Region  where RegionId=@RegionId  
END    
    
ELSE IF(@Type='Delete')        
BEGIN        
 --DELETE FROM Region  where RegionId=@RegionId 
 update Region SET IsDeleted=1 where RegionId=@RegionId
END     
    
    
END