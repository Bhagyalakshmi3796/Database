﻿

        
CREATE procedure [dbo].[Technology_proc]      
(      
@TechnologyId int,      
@TechnologyName nvarchar(100),   
@DomainId int,
@Type nvarchar(100)      
)      
AS BEGIN      
IF(@Type='post')      
BEGIN INSERT INTO Technology(TechnologyName,DomainId)
VALUES(@TechnologyName,@DomainId)      
END      
   

ELSE IF(@Type='get')          
BEGIN          
  SELECT * FROM Technology where IsDeleted=0 order by TechnologyId desc          
END         
      
 
ELSE IF(@Type='getid')          
BEGIN          
  SELECT * FROM Technology where TechnologyId=@TechnologyId        
END       
   
ELSE IF(@Type='update')          
BEGIN          
update Technology SET       
      
TechnologyName=@TechnologyName, DomainId=@DomainId  where TechnologyId=@TechnologyId    
END      

        
ELSE IF(@Type='Delete')          
BEGIN          
 --DELETE FROM Technology  where TechnologyId=@TechnologyId   
  update Technology SET IsDeleted=1 where TechnologyId=@TechnologyId   
END       
      
      
END
