﻿
  
CREATE procedure [dbo].[Account_proc]  
(  
@AccountId int,  
@AccountName nvarchar(100), 
--@IsDeleted int,
@Type nvarchar(100)  
)  
AS BEGIN  
IF(@Type='post')  
BEGIN INSERT INTO Account(AccountId,AccountName)  
VALUES(@AccountId,@AccountName)  
END  
  
ELSE IF(@Type='get')      
BEGIN      
  SELECT * FROM Account where IsDeleted=0 order by AccountId desc      
END     
  
  
ELSE IF(@Type='getid')      
BEGIN      
  SELECT * FROM Account where AccountId=@AccountId     
END   
  
ELSE IF(@Type='update')      
BEGIN      
update Account SET   
AccountId=@AccountId,AccountName=@AccountName  WHERE AccountId=@AccountId  
  
END  
  
ELSE IF(@Type='Delete')      
BEGIN      
--DELETE FROM Account WHERE AccountId=@AccountId   
 update Account SET IsDeleted=1 where AccountId=@AccountId

END   
  
  
END