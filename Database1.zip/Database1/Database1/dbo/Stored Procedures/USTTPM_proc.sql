﻿

    
CREATE procedure [dbo].[USTTPM_proc]    
(    
@USTTPMId int,    
@USTTPMName nvarchar(100),    
@Type nvarchar(100)    
)    
AS BEGIN    
IF(@Type='post')    
BEGIN INSERT INTO USTTPM(USTTPMName)    
VALUES(@USTTPMName)    
END    
    
ELSE IF(@Type='get')        
BEGIN        
  SELECT * FROM USTTPM where IsDeleted=0 order by USTTPMId desc        
END       
    
    
ELSE IF(@Type='getid')        
BEGIN        
  SELECT * FROM USTTPM where USTTPMId= @USTTPMId     
END     
    
ELSE IF(@Type='update')        
BEGIN        
update  USTTPM SET     
USTTPMName=@USTTPMName  WHERE USTTPMId= @USTTPMId  
    
END    
    
ELSE IF(@Type='Delete')        
BEGIN        
 --DELETE FROM USTTPM where USTTPMId= @USTTPMId    
   update USTTPM SET IsDeleted=1 where USTTPMId= @USTTPMId   
END     
    
    
END
