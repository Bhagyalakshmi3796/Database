﻿
    
CREATE procedure [dbo].[Recruiter_proc]    
(    
@RecruiterId int,    
@RecruiterName nvarchar(100),    
@Type nvarchar(100)    
)    
AS BEGIN    
IF(@Type='post')    
BEGIN INSERT INTO Recruiter(RecruiterName)    
VALUES(@RecruiterName)    
END    
    
ELSE IF(@Type='get')        
BEGIN        
  SELECT * FROM Recruiter where IsDeleted=0 order by RecruiterId desc        
END       
    
    
ELSE IF(@Type='getid')        
BEGIN        
  SELECT * FROM Recruiter where RecruiterId= @RecruiterId     
END     
    
ELSE IF(@Type='update')        
BEGIN        
update Recruiter SET     
RecruiterName=@RecruiterName  WHERE RecruiterId= @RecruiterId  
    
END    
    
ELSE IF(@Type='Delete')        
BEGIN        
 --DELETE FROM Recruiter WHERE RecruiterId= @RecruiterId  
  update Recruiter SET IsDeleted=1 where RecruiterId= @RecruiterId  
END     
    
    
END