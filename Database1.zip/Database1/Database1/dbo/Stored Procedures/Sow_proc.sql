﻿
       
CREATE procedure [dbo].[Sow_proc](            
 @SowId int,   
 @SoName nvarchar(100) NULL,     
 @JRCode nvarchar(10),            
 @RequestCreationDate datetime,            
 @AccountId int Null,            
 @TechnologyId nvarchar(500) NULL,            
 @Role nvarchar(100) NULL,            
 @LocationId int null , 
 @RegionId int null , 
 @TargetOpenPositions int NULL,            
 @PositionsTobeClosed int NULL,            
 @USTPOCId   int null ,         
 @RecruiterId  int null ,           
 @USTTPMId    int null ,         
 @DellManagerId   int null ,   
 @StatusId int NULL,            
 @Band nvarchar(100) NULL,            
 @ProjectId nvarchar(100) NULL,            
 @AccountManager nvarchar(200) NULL,            
 @ExternalResource nvarchar(100) NULL,            
 @InternalResource nvarchar(100) NULL,           
 @Type nvarchar(100))          
 as            
 Begin             
 If(@Type='insert')          
 begin          
 Insert into SOW(SoName,JRCode,RequestCreationDate,AccountId,TechnologyId,Role,LocationId,RegionId,TargetOpenPositions,PositionsTobeClosed,            
 USTPOCId,RecruiterId,USTTPMId,DellManagerId,StatusId,Band,ProjectId,AccountManager,ExternalResource,InternalResource)             
 Values            
 (@SoName,@JRCode,@RequestCreationDate,@AccountId,@TechnologyId,@Role,@LocationId,@RegionId,@TargetOpenPositions,@PositionsTobeClosed,            
 @USTPOCId,@RecruiterId,@USTTPMId,@DellManagerId,@StatusId,@Band,@ProjectId,@AccountManager,@ExternalResource,@InternalResource)            
 end          
 else if(@Type='get')          
 begin          
 select * from SOW where IsDeleted=0 order by SowId desc          
 end          
 else if(@Type='getid')          
 begin          
 select * from SOW where SowId=@SowId          
 end          
 else if(@Type='update')          
 begin          
 update SOW set          
 SoName=@SoName,JRCode=@JRCode,RequestCreationDate=@RequestCreationDate,AccountId=@AccountId,TechnologyId=@TechnologyId,          
 Role=@Role,LocationId=@LocationId,TargetOpenPositions=@TargetOpenPositions,PositionsTobeClosed=@PositionsTobeClosed,            
 USTPOCId=@USTPOCId,RecruiterId=@RecruiterId,USTTPMId=@USTTPMId,DellManagerId=@DellManagerId,StatusId=@StatusId,Band=@Band,          
 ProjectId=@ProjectId,AccountManager=@AccountManager,ExternalResource=@ExternalResource,InternalResource=@InternalResource        
 Where SowId=@SowId;     
end          
          
else if(@Type='Delete')          
 begin          
 --delete from SOW where SowId=@SowId  
 update SOW SET IsDeleted=1 where SowId=@SowId 
 end          
            
 end 
