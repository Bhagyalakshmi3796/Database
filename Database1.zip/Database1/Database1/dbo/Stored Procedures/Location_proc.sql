﻿     
CREATE procedure [dbo].[Location_proc]      
(      
@LocationId int,      
@Location nvarchar(50),  
@RegionId int,  
@Type nvarchar(100)      
)       
AS BEGIN      
IF(@Type='post')      
BEGIN   
INSERT INTO Location(Location,RegionId)      
VALUES(@Location,@RegionId)      
END      
      
ELSE IF(@Type='get')          
BEGIN          
  SELECT * FROM Location where IsDeleted=0 order by LocationId desc          
END         
      
      
ELSE IF(@Type='getid')          
BEGIN          
  SELECT * FROM Location where LocationId=@LocationId         
END       
      
ELSE IF(@Type='update')          
BEGIN          
update Location SET       
Location=@Location,RegionId=@RegionId    where LocationId=@LocationId  
END      
      
ELSE IF(@Type='Delete')          
BEGIN          
-- DELETE FROM Location WHERE LocationId=@LocationId 
 update Location SET IsDeleted=1 where LocationId=@LocationId 
END       
      
      
END