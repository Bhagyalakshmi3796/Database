﻿create procedure usp_addCandidateData
@CandidateId int,
@CandidateName nvarchar(50),
@MobileNo nvarchar(50),
@DOB date,
@EmailId nvarchar(50),
@Location nvarchar(50),
@Skills nvarchar(max),
@JoiningDate datetime,
@IsInternal bit
as
begin
set nocount on
insert into Candidate(CandidateId,CandidateName,MobileNo,DOB,EmailId,Location,Skills,JoiningDate,IsInternal)
values(@CandidateId,@CandidateName,@MobileNo,@DOB,@EmailId,@Location,@Skills,@JoiningDate,@IsInternal)
end