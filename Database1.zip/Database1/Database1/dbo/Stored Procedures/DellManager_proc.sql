﻿
    
CREATE procedure [dbo].[DellManager_proc]    
(    
@DellManagerId int,    
@DellManagerName nvarchar(100),    
@Type nvarchar(100)    
)    
AS BEGIN    
IF(@Type='post')    
BEGIN INSERT INTO DellManager(DellManagerName)    
VALUES(@DellManagerName)    
END    
    
ELSE IF(@Type='get')        
BEGIN        
  SELECT * FROM DellManager where IsDeleted=0 order by DellManagerId desc        
END       
    
    
ELSE IF(@Type='getid')        
BEGIN        
  SELECT * FROM DellManager where DellManagerId= @DellManagerId     
END     
    
ELSE IF(@Type='update')        
BEGIN        
update DellManager SET     
DellManagerName=@DellManagerName  WHERE DellManagerId= @DellManagerId  
    
END    
    
ELSE IF(@Type='Delete')        
BEGIN        
 --DELETE FROM DellManager WHERE DellManagerId= @DellManagerId   
  update DellManager SET IsDeleted=1 where DellManagerId= @DellManagerId   
END     
    
    
END
