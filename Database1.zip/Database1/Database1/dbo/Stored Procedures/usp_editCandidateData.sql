﻿create procedure usp_editCandidateData
@CandidateId int,
@CandidateName nvarchar(50),
@MobileNo nvarchar(50),
@DOB date,
@EmailId nvarchar(50),
@Location nvarchar(50),
@Skills nvarchar(max),
@JoiningDate datetime,
@IsInternal bit
as
begin
UPDATE Candidate
SET CandidateName=@CandidateName,
MobileNo=@MobileNo,DOB=@DOB,EmailId=@EmailId,Location=@Location,Skills=@Skills,
JoiningDate=@JoiningDate,IsInternal=@IsInternal
Where CandidateId=@CandidateId;
end
