﻿create procedure usp_showCandidateData
@CandidateId int 
as
begin 
set nocount on
select CandidateId,CandidateName,MobileNo,DOB,EmailId,Location,Skills,JoiningDate,IsInternal
from Candidate where CandidateId=@CandidateId
end