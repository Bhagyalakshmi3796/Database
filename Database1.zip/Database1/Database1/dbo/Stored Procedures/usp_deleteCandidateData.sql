﻿

CREATE procedure [dbo].[usp_deleteCandidateData]
@CandidateId int
as
begin
--DELETE from Candidate 
--where CandidateId=@CandidateId
 update Candidate SET IsDeleted=1 where CandidateId=@CandidateId
end

