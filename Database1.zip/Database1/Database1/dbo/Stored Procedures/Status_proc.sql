﻿


 
CREATE procedure [dbo].[Status_proc]
(
@StatusId int,
@StatusName nvarchar(100),
@Type nvarchar(100)
)
AS BEGIN
IF(@Type='post')
BEGIN INSERT INTO Status(StatusName)
VALUES(@StatusName)
END

ELSE IF(@Type='get')    
BEGIN    
  SELECT * FROM Status where IsDeleted=0 order by StatusId desc    
END   


ELSE IF(@Type='getid')    
BEGIN    
  SELECT * FROM Status where StatusId=@StatusId   
END 

ELSE IF(@Type='update')    
BEGIN    
update Status SET 
StatusName=@StatusName

END

ELSE IF(@Type='Delete')    
BEGIN    
-- DELETE FROM Status WHERE StatusId=@StatusId    
 update Status SET IsDeleted=1 where StatusId=@StatusId   
END 


END
