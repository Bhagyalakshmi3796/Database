﻿
CREATE procedure [dbo].[loginproc]  
(  
@LoginName varchar(100),
@LoginPassword varchar(100)
)  
as

--DECLARE @LoginName as varchar(100)
--DECLARE @LoginPassword as varchar(100)


 Begin 
 if Exists (SELECT * FROM [Login] where LoginName=@LoginName and LoginPassword=@LoginPassword)
 Begin 

 DECLARE @listStr VARCHAR(MAX)
SELECT @listStr = COALESCE(@listStr+',' ,'') + S.ScreenName
 FROM [Login] L INNER Join Roles R ON L.RoleId= R.RoleId 
 INNER Join RoleScreens RS ON R.RoleId=RS.RoleId 
 INNER JOIN Screens S ON RS.ScreenId=S.ScreenId
  where LoginName=@LoginName and LoginPassword=@LoginPassword


 select DISTINCT L.LoginName, L.EmailId,R.RoleName,@listStr as 'ScreenNames','1' as [status] 
 FROM [Login] L INNER Join Roles R ON L.RoleId= R.RoleId 
 INNER Join RoleScreens RS ON R.RoleId=RS.RoleId 
 INNER JOIN Screens S ON RS.ScreenId=S.ScreenId
 where LoginName=@LoginName and LoginPassword=@LoginPassword
 end

 else
 
 Begin 

 select  '' as LoginName, '' as EmailId,'' as RoleName,'' as ScreenNames,'0' as [status];
   
 end

 END
 
